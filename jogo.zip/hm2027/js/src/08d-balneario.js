// Balneário e química de equipa (2026-10-08, pedido do utilizador: "quero implementar" a ideia 5,
// com estas decisões de desenho: valor por equipa + liderança; nunca mostrar o número, só um
// estado qualitativo; sobe e desce com continuidade do plantel, resultados, descontentes e
// promessas falhadas, líderes/capitão/jogadores da casa; efeito num modificador pequeno do
// motor E nos eventos narrativos; o utilizador escolhe o capitão e faz uma conversa de grupo).
//
// Modelo (team.balneario, criado de forma preguiçosa para clubes principais — nunca para equipas
// B nem para selecções virtuais):
//   coesao        número 0–100, OCULTO (a interface só mostra rótulo, tendência e razões)
//   capitaoId     capitão escolhido pelo utilizador (null = automático, o melhor líder)
//   presenca      { jogadorId: instante de chegada (ms) } — antiguidade no clube sem tocar em
//                 nenhum dos muitos caminhos de transferência (a chegada é detectada na primeira
//                 sincronização depois de o jogador aparecer no plantel)
//   lideresIds    os 3 líderes da última sincronização mensal (detecta a saída de um líder)
//   refMes        valor da coesão um mês antes, para a tendência
//   fatores       últimos sub-valores (-1..1) usados para explicar o ambiente em texto
//   ultimaConversa, conversas[]  conversa de grupo (cooldown e histórico)
//
// A coesão tem duas componentes: um ALVO estrutural (continuidade, líderes, clima de satisfação,
// jogadores da casa, capitão) para onde o valor deriva 30% por mês, e impulsos imediatos dos
// resultados (vitórias e derrotas, séries) e de saídas de líderes.

const BALNEARIO_NEUTRO = 55;
const BALNEARIO_BASE_ALVO = 52; // alvo estrutural de um grupo sem factores marcantes (ligeiramente abaixo do neutro do motor)
const BALNEARIO_MODIFICADOR_MAX = 0.035; // ±3,5% em ataque e defesa, nunca vale mais do que o OVR
const BALNEARIO_CONVERSA_COOLDOWN_DIAS = 21;
const BALNEARIO_NIVEIS = [
  { id: "unido", min: 78, label: "Balneário unido", cor: "#3FA34D", texto: "O grupo joga unido: os jogadores confiam uns nos outros e assumem a responsabilidade em conjunto." },
  { id: "bom", min: 64, label: "Bom ambiente", cor: "#86C440", texto: "O ambiente no plantel é positivo e o grupo trabalha bem em conjunto." },
  { id: "normal", min: 48, label: "Ambiente normal", cor: "#F3C623", texto: "Sem sobressaltos, mas também sem uma ligação forte entre os jogadores." },
  { id: "tenso", min: 33, label: "Tensão no balneário", cor: "#E8892B", texto: "Há tensão no grupo. Uma má sequência pode transformar isto numa crise." },
  { id: "dividido", min: 0, label: "Balneário dividido", cor: "#D6402F", texto: "O balneário está dividido e isso já se nota dentro e fora de campo." },
];

function balnearioElegivel(team) {
  return !!(team && Array.isArray(team.players) && team.players.length > 0 && !team.equipaPrincipalId &&
    !String(team.id || "").startsWith("selecaoNacional-"));
}
function balnearioAgoMs() {
  const d = state.currentDate instanceof Date ? state.currentDate : new Date(state.currentDate || Date.now());
  return d.getTime();
}
function balnearioHash01(str) {
  let h = 2166136261;
  const s = String(str);
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return ((h >>> 0) % 100000) / 100000;
}
function balnearioGauss() {
  const u1 = Math.max(1e-9, Math.random()), u2 = Math.random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
function balnearioSquad(team) {
  return (team.players || []).filter(p => p && !p.__provisional);
}
function balnearioTenureYears(b, p) {
  const t = b.presenca && b.presenca[p.id];
  return t ? Math.max(0, (balnearioAgoMs() - t) / (365.25 * 86400000)) : 0;
}
function balnearioLeaderScore(b, p) {
  const lid = p.attrs && p.attrs.lideranca != null ? p.attrs.lideranca : 10;
  return lid + Math.min(balnearioTenureYears(b, p), 6) * 0.7 + (overall(p) - 10) * 0.25 + (p.age >= 26 ? 0.8 : 0) + persLiderBonus(p);
}
function balnearioNivel(coesao) {
  return BALNEARIO_NIVEIS.find(n => coesao >= n.min) || BALNEARIO_NIVEIS[BALNEARIO_NIVEIS.length - 1];
}

function ensureBalneario(team) {
  if (!balnearioElegivel(team)) return null;
  if (team.balneario && team.balneario.v === 1 && typeof team.balneario.coesao === "number") return team.balneario;
  const now = balnearioAgoMs();
  const presenca = {};
  balnearioSquad(team).forEach(p => {
    // Antiguidade inicial semeada pelo id: um jogador mais novo não pode ter mais anos de clube
    // do que de carreira, e o resto do plantel tem desvio-padrão (0,2 a ~4,4 anos).
    const maxAnos = Math.max(0.2, Math.min((p.age || 24) - 17, 0.2 + balnearioHash01(p.id) * 4.2));
    presenca[p.id] = now - maxAnos * 365.25 * 86400000;
  });
  const b = { v: 1, coesao: BALNEARIO_NEUTRO, capitaoId: null, presenca, lideresIds: [], refMes: BALNEARIO_NEUTRO, fatores: null, ultimaConversa: null, ultimaConversaResultado: null, conversas: [], ultimoNivel: null };
  team.balneario = b;
  const f = balnearioFatores(team, b);
  // Arranque: perto do alvo estrutural, com variação própria de cada clube.
  b.coesao = clamp(f.alvo + (balnearioHash01("coesao-a-" + team.id) + balnearioHash01("coesao-b-" + team.id) - 1) * 24, 12, 92);
  b.refMes = b.coesao;
  b.lideresIds = f.lideres.map(p => p.id);
  b.fatores = balnearioFatoresResumo(f);
  b.ultimoNivel = balnearioNivel(b.coesao).id;
  return b;
}

// Chegadas e saídas de jogadores, onde quer que tenham acontecido. A saída de um dos três
// líderes abala o grupo de imediato (uma única vez por sincronização).
function syncBalnearioPresenca(team) {
  const b = ensureBalneario(team);
  if (!b) return null;
  const squad = balnearioSquad(team);
  const ids = new Set(squad.map(p => p.id));
  const now = balnearioAgoMs();
  let saiuLider = false;
  (b.lideresIds || []).forEach(id => { if (!ids.has(id)) saiuLider = true; });
  squad.forEach(p => { if (!b.presenca[p.id]) b.presenca[p.id] = now; });
  Object.keys(b.presenca).forEach(id => { if (!ids.has(id)) delete b.presenca[id]; });
  if (saiuLider && squad.length) {
    b.coesao = clamp(b.coesao - 4.5, 3, 99);
    b.lideresIds = squad.slice().sort((x, y) => balnearioLeaderScore(b, y) - balnearioLeaderScore(b, x)).slice(0, 3).map(p => p.id);
    if (b.capitaoId && !ids.has(b.capitaoId)) b.capitaoId = null;
  }
  if (b.capitaoId && !ids.has(b.capitaoId)) b.capitaoId = null;
  return b;
}

function balnearioResolverCapitao(team, b) {
  b = b || ensureBalneario(team);
  if (!b) return { player: null, auto: true };
  const squad = balnearioSquad(team);
  const escolhido = b.capitaoId ? squad.find(p => p.id === b.capitaoId) : null;
  if (escolhido) return { player: escolhido, auto: false };
  const candidatos = squad.filter(p => (p.age || 0) >= 19);
  const pool = candidatos.length ? candidatos : squad;
  const melhor = pool.slice().sort((x, y) => balnearioLeaderScore(b, y) - balnearioLeaderScore(b, x))[0] || null;
  return { player: melhor, auto: true };
}

function balnearioFatores(team, b) {
  const squad = balnearioSquad(team);
  const n = Math.max(1, squad.length);
  const core = squad.slice().sort((x, y) => overall(y) - overall(x)).slice(0, 8);
  const coreIds = new Set(core.map(p => p.id));
  const avgYears = core.length ? core.reduce((s, p) => s + balnearioTenureYears(b, p), 0) / core.length : 0;
  const recemChegados = squad.filter(p => balnearioTenureYears(b, p) < 60 / 365.25).length / n;
  const continuidade = clamp((avgYears - 1.6) / 2.2 - recemChegados * 1.6, -1, 1);

  const lideres = squad.slice().sort((x, y) => balnearioLeaderScore(b, y) - balnearioLeaderScore(b, x)).slice(0, 3);
  const mediaLid = lideres.length ? lideres.reduce((s, p) => s + (p.attrs && p.attrs.lideranca != null ? p.attrs.lideranca : 10), 0) / lideres.length : 10;
  const mediaSatLid = lideres.length ? lideres.reduce((s, p) => s + (p.satisfacao != null ? p.satisfacao : 70), 0) / lideres.length : 70;
  const lideranca = clamp((mediaLid - 11.5) / 4.5 - (mediaSatLid < 45 ? 0.4 : 0), -1, 1);

  let pesoTotal = 0, pesoDesc = 0, pesoInq = 0, somaSat = 0;
  squad.forEach(p => {
    const w = p.titular ? 2 : 1;
    const s = p.satisfacao != null ? p.satisfacao : 70;
    pesoTotal += w; somaSat += s * w;
    if (s < 40) pesoDesc += w; else if (s < 55) pesoInq += w;
  });
  const mediaSat = pesoTotal ? somaSat / pesoTotal : 70;
  const negativo = clamp((pesoDesc / Math.max(1, pesoTotal)) * 2.6 + (pesoInq / Math.max(1, pesoTotal)) * 0.8, 0, 1);
  const lesionadosNucleo = core.filter(p => (p.diasLesao || 0) >= 30).length;
  const clima = clamp((mediaSat >= 72 ? 0.35 : 0) - negativo - Math.min(0.3, lesionadosNucleo * 0.08), -1, 0.4);

  const casa = clamp((squad.filter(p => p.clubeFormadorId && p.clubeFormadorId === team.id).length / n) * 2, 0, 1);

  const cap = balnearioResolverCapitao(team, b).player;
  let capitao = 0;
  if (cap) {
    const lid = cap.attrs && cap.attrs.lideranca != null ? cap.attrs.lideranca : 10;
    const sat = cap.satisfacao != null ? cap.satisfacao : 70;
    capitao = clamp((lid - 11) / 6, -1, 1) * 0.55 + clamp((sat - 60) / 40, -1, 1) * 0.25 + clamp(balnearioTenureYears(b, cap) / 4, 0, 1) * 0.2 -
      (!coreIds.has(cap.id) && !cap.titular ? 0.15 : 0);
  }
  const alvo = clamp(BALNEARIO_BASE_ALVO + 13 * continuidade + 13 * lideranca + 12 * clima + 6 * casa + 6 * capitao + persBalnearioAlvo(squad), 8, 96);
  return { continuidade, lideranca, clima, casa, capitao, alvo, lideres, mediaSat };
}
function balnearioFatoresResumo(f) {
  const r = v => Math.round(v * 100) / 100;
  return { continuidade: r(f.continuidade), lideranca: r(f.lideranca), clima: r(f.clima), casa: r(f.casa), capitao: r(f.capitao) };
}

// Modificador de motor. O(1): lê só o valor guardado (é chamado a cada tick de jogo).
function balnearioFactor(team) {
  const b = team && team.balneario;
  if (!b || typeof b.coesao !== "number") return 1;
  return 1 + clamp((b.coesao - BALNEARIO_NEUTRO) / 45, -1, 1) * BALNEARIO_MODIFICADOR_MAX;
}
function balnearioMoralMod(team) {
  const b = team && team.balneario;
  if (!b || typeof b.coesao !== "number") return 0;
  return clamp((b.coesao - BALNEARIO_NEUTRO) / 55, -1, 1) * 0.25;
}

// Resultado de um jogo (chamado depois de recentResults já ter o novo resultado).
function registerBalnearioResult(team, res, goalDiff) {
  if (!balnearioElegivel(team)) return;
  const b = ensureBalneario(team);
  if (!b) return;
  syncBalnearioPresenca(team);
  let d = res === "V" ? 0.9 : res === "D" ? -0.9 : 0;
  const last3 = (team.recentResults || []).slice(-3);
  if (last3.length === 3 && last3.every(x => x === "V")) d += 0.8;
  if (last3.length === 3 && last3.every(x => x === "D")) d -= 1.0;
  if (res === "D" && goalDiff <= -4) d -= 0.7;
  if (res === "V" && goalDiff >= 5) d += 0.3;
  // Rendimentos decrescentes: perto dos extremos é mais difícil continuar a afastar-se do neutro.
  const longe = Math.abs(b.coesao - BALNEARIO_NEUTRO) / 55;
  if ((d > 0 && b.coesao > BALNEARIO_NEUTRO) || (d < 0 && b.coesao < BALNEARIO_NEUTRO)) d *= 1 - longe * 0.5;
  b.coesao = clamp(b.coesao + d, 3, 99);
}

function balnearioRazoes(team, b) {
  const f = b.fatores || {};
  const forma = (team.recentResults || []).slice(-5);
  const vit = forma.filter(x => x === "V").length, der = forma.filter(x => x === "D").length;
  const cand = [];
  const add = (mag, tom, texto) => cand.push({ mag: Math.abs(mag), tom, texto });
  if (f.continuidade > 0.3) add(f.continuidade, "pos", "Núcleo estável, com muitos anos a jogar junto");
  if (f.continuidade < -0.2) add(f.continuidade, "neg", "Muitas caras novas ainda a integrar-se");
  if (f.lideranca > 0.3) add(f.lideranca, "pos", "Líderes fortes no grupo");
  if (f.lideranca < -0.25) add(f.lideranca, "neg", "Falta de líderes no balneário");
  if (f.clima > 0.2) add(f.clima * 1.5, "pos", "Jogadores satisfeitos com o seu papel");
  if (f.clima < -0.2) add(f.clima, "neg", "Descontentamento entre jogadores importantes");
  if (f.casa > 0.35) add(f.casa * 0.7, "pos", "Forte presença de jogadores da casa");
  if (f.capitao > 0.4) add(f.capitao, "pos", "Capitão respeitado pelo grupo");
  if (f.capitao < -0.05) add(f.capitao + 0.3, "neg", "Capitão com pouco peso no grupo");
  if (forma.length >= 4 && vit >= 4) add(0.6, "pos", "Boa fase de resultados");
  if (forma.length >= 4 && der >= 3) add(0.6, "neg", "Os maus resultados pesam no grupo");
  return cand.sort((x, y) => y.mag - x.mag).slice(0, 4);
}

function balnearioInfo(team) {
  const b = syncBalnearioPresenca(team) || ensureBalneario(team);
  if (!b) return null;
  const nivel = balnearioNivel(b.coesao);
  const delta = b.coesao - (b.refMes != null ? b.refMes : b.coesao);
  const tendencia = delta > 2.5 ? "melhorar" : delta < -2.5 ? "piorar" : "estavel";
  const cap = balnearioResolverCapitao(team, b);
  const ate = balnearioConversaProxima(team, b);
  return { nivel, tendencia, razoes: balnearioRazoes(team, b), capitao: cap.player, capitaoAuto: cap.auto, conversa: ate, ultimaConversaResultado: b.ultimaConversaResultado };
}

// Actualização mensal (chamada por processMonthlyFinances, só clubes principais).
function updateBalnearioMonthly(team) {
  const b = ensureBalneario(team);
  if (!b) return;
  syncBalnearioPresenca(team);
  const f = balnearioFatores(team, b);
  const antes = b.coesao;
  b.coesao = clamp(b.coesao + (f.alvo - b.coesao) * 0.3, 3, 99);
  b.refMes = antes;
  b.lideresIds = f.lideres.map(p => p.id);
  b.fatores = balnearioFatoresResumo(f);
  const m = clamp((b.coesao - BALNEARIO_NEUTRO) / 55, -1, 1) * 0.9;
  if (Math.abs(m) > 0.05) balnearioSquad(team).forEach(p => { p.moral = clamp((p.moral != null ? p.moral : 60) + m, 0, 100); });
  const nivel = balnearioNivel(b.coesao);
  if (team.id === state.userTeamId && b.ultimoNivel && b.ultimoNivel !== nivel.id) {
    const ordem = BALNEARIO_NIVEIS.map(n => n.id).reverse();
    const subiu = ordem.indexOf(nivel.id) > ordem.indexOf(b.ultimoNivel);
    const razao = balnearioRazoes(team, b).find(r => r.tom === (subiu ? "pos" : "neg"));
    const texto = subiu
      ? `O ambiente no balneário melhorou: ${nivel.label.toLowerCase()}.${razao ? " " + razao.texto + "." : ""}`
      : `O ambiente no balneário deteriorou-se: ${nivel.label.toLowerCase()}.${razao ? " " + razao.texto + "." : ""}`;
    if (typeof pushNews === "function") pushNews(state.currentDate, texto, "evento", "Ambiente no balneário", { teamId: team.id });
  }
  b.ultimoNivel = nivel.id;
}

// ---------------------------------------------------------------- Capitão
function setBalnearioCapitao(team, playerId) {
  const b = ensureBalneario(team);
  if (!b) return { ok: false, reason: "Sem balneário." };
  const squad = balnearioSquad(team);
  if (playerId == null) {
    b.capitaoId = null;
    return { ok: true, auto: true };
  }
  const novo = squad.find(p => p.id === playerId);
  if (!novo) return { ok: false, reason: "Esse jogador já não está no plantel." };
  const anterior = balnearioResolverCapitao(team, b);
  if (anterior.player && anterior.player.id === novo.id && !anterior.auto) return { ok: true, igual: true };
  // O capitão anterior (escolhido) sente a perda da braçadeira; o novo ganha confiança. Se o
  // novo capitão for o líder natural do grupo, o efeito de má vontade praticamente desaparece.
  if (anterior.player && !anterior.auto && anterior.player.id !== novo.id) {
    anterior.player.satisfacao = clamp((anterior.player.satisfacao != null ? anterior.player.satisfacao : 70) - 3, 0, 100);
  }
  novo.satisfacao = clamp((novo.satisfacao != null ? novo.satisfacao : 70) + 3, 0, 100);
  novo.moral = clamp((novo.moral != null ? novo.moral : 60) + 3, 0, 100);
  b.capitaoId = novo.id;
  return { ok: true, capitao: novo };
}

// ---------------------------------------------------------------- Conversa de grupo
function balnearioConversaProxima(team, b) {
  b = b || ensureBalneario(team);
  if (!b || !b.ultimaConversa) return { ok: true, dias: 0 };
  const dias = (balnearioAgoMs() - new Date(b.ultimaConversa).getTime()) / 86400000;
  const resta = Math.ceil(BALNEARIO_CONVERSA_COOLDOWN_DIAS - dias);
  return resta > 0 ? { ok: false, dias: resta } : { ok: true, dias: 0 };
}
const BALNEARIO_CONVERSA_TEXTOS = {
  uniao: {
    bem: ["O apelo à união caiu bem. Os jogadores saíram da conversa com o ar de quem quer remar todos para o mesmo lado.", "A mensagem foi simples e chegou ao grupo: ganha-se juntos e perde-se juntos. Notou-se no treino seguinte."],
    neutro: ["A conversa foi ouvida com respeito, mas sem grande efeito. Ninguém discordou, ninguém ficou entusiasmado.", "O grupo ouviu em silêncio. Vai ser preciso mostrar com resultados que o discurso tem sustento."],
    mal: ["O apelo soou a frase feita. Alguns jogadores trocaram olhares e a conversa deixou o ambiente pior do que estava.", "A conversa não foi bem recebida: houve quem achasse que o problema estava noutro lado."],
  },
  exigir: {
    bem: ["O tom exigente era o que o grupo precisava. Houve uma reacção imediata e os jogadores prometeram dar mais.", "Foste duro, mas justo. O balneário percebeu que não há lugar para facilitismos e respondeu em conformidade."],
    neutro: ["A exigência foi ouvida, mas sem grande impacto. Os jogadores já sabiam o que se esperava deles.", "O discurso foi firme. Veremos nos próximos jogos se foi compreendido."],
    mal: ["A cobrança caiu mal. Os jogadores sentiram-se injustiçados e o ambiente ficou mais pesado.", "Exigir mais a um grupo que já dá tudo, ou que está em baixo, saiu pela culatra: alguns jogadores ficaram ressentidos."],
  },
  elogiar: {
    bem: ["O elogio foi merecido e o grupo sentiu-o. O balneário está mais confiante e unido à volta do trabalho feito.", "Reconheceste o esforço no momento certo. A confiança do grupo cresceu e notou-se no ambiente."],
    neutro: ["Os elogios foram bem aceites, mas sem efeito visível.", "A conversa agradou, mas os jogadores sabem que ainda há muito por fazer."],
    mal: ["Os elogios soaram fora de tempo. Com os resultados que existem, os jogadores acharam que a mensagem estava desfasada da realidade.", "O elogio não convenceu o balneário: houve quem visse nele falta de ambição."],
  },
};
function balnearioConversaDeGrupo(team, tom) {
  const b = ensureBalneario(team);
  if (!b) return { ok: false, reason: "Sem balneário." };
  if (!BALNEARIO_CONVERSA_TEXTOS[tom]) return { ok: false, reason: "Tom desconhecido." };
  const disp = balnearioConversaProxima(team, b);
  if (!disp.ok) return { ok: false, reason: `Já falaste com o grupo há pouco. Podes repetir daqui a ${disp.dias} dia${disp.dias === 1 ? "" : "s"}.` };
  syncBalnearioPresenca(team);
  const forma = (team.recentResults || []).slice(-5);
  const vit = forma.filter(x => x === "V").length, der = forma.filter(x => x === "D").length;
  const f = balnearioFatores(team, b);
  let base;
  if (tom === "uniao") base = b.coesao < BALNEARIO_NEUTRO ? 4.0 : 1.8;
  else if (tom === "exigir") base = (der >= 3 || (der >= 2 && vit <= 1)) ? (b.coesao < 40 ? 2.0 : 4.5) : vit >= 4 ? -3.5 : -1.5;
  else base = vit >= 3 ? 3.5 : der >= 3 ? -3.0 : 1.0;
  const credibilidade = clamp(0.75 + f.capitao * 0.35, 0.4, 1.15);
  const repetida = b.conversas && b.conversas[0] && (balnearioAgoMs() - new Date(b.conversas[0].data).getTime()) / 86400000 < 45;
  const delta = base * credibilidade * (repetida ? 0.5 : 1) + balnearioGauss() * 1.4;
  b.coesao = clamp(b.coesao + delta, 3, 99);
  balnearioSquad(team).forEach(p => {
    p.moral = clamp((p.moral != null ? p.moral : 60) + delta * 0.8, 0, 100);
    if (delta < 0 && (p.satisfacao != null ? p.satisfacao : 70) < 40) p.satisfacao = clamp(p.satisfacao - 2, 0, 100);
  });
  const resultado = delta >= 2.5 ? "bem" : delta <= -1 ? "mal" : "neutro";
  const pool = BALNEARIO_CONVERSA_TEXTOS[tom][resultado];
  const texto = pool[Math.floor(Math.random() * pool.length)];
  const data = new Date(balnearioAgoMs()).toISOString();
  b.ultimaConversa = data;
  b.ultimaConversaResultado = { data, tom, resultado, texto };
  b.conversas.unshift({ data, tom, resultado });
  if (b.conversas.length > 12) b.conversas.length = 12;
  return { ok: true, resultado, texto, delta };
}

// ---------------------------------------------------------------- Interface (Plantel)
function balnearioIsCaptain(team, player) {
  if (!team || !team.balneario || !player) return false;
  const cap = balnearioResolverCapitao(team, team.balneario).player;
  return !!cap && cap.id === player.id;
}
function balnearioTendenciaHtml(t) {
  if (t === "melhorar") return '<span class="bal-trend bal-trend-up" title="O ambiente está a melhorar">▲ a melhorar</span>';
  if (t === "piorar") return '<span class="bal-trend bal-trend-down" title="O ambiente está a piorar">▼ a piorar</span>';
  return '<span class="bal-trend bal-trend-flat" title="O ambiente mantém-se estável">▬ estável</span>';
}
function renderBalnearioPanel() {
  const el = document.getElementById("balnearioPanel");
  if (!el) return;
  const mine = typeof myTeam === "function" ? myTeam() : null;
  const club = mine && state.teams[plantelActiveTeamId()];
  if (!mine || state.plantelViewMode === "academia" || !club || club.id !== mine.id) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  const info = balnearioInfo(mine);
  if (!info) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  el.classList.remove("hidden");
  const razoes = info.razoes.length
    ? info.razoes.map(r => `<span class="bal-chip bal-chip-${r.tom}">${r.tom === "pos" ? "＋" : "−"} ${escapeHtml(r.texto)}</span>`).join("")
    : '<span class="bal-chip">Sem factores de destaque</span>';
  const ultima = info.ultimaConversaResultado;
  const capNome = info.capitao ? `${escapeHtml(info.capitao.name)}${info.capitaoAuto ? ' <span class="helptext" style="display:inline;">(automático)</span>' : ""}` : "—";
  const conv = info.conversa;
  el.innerHTML = `
    <div class="bal-head">
      <span class="bal-dot" style="background:${info.nivel.cor};"></span>
      <b class="bal-label">${info.nivel.label}</b>
      ${balnearioTendenciaHtml(info.tendencia)}
    </div>
    <div class="bal-text">${escapeHtml(info.nivel.texto)}</div>
    <div class="bal-chips">${razoes}</div>
    <div class="bal-actions">
      <span class="bal-cap">Capitão: <b>${capNome}</b></span>
      <button class="btn btn-ghost bal-btn" id="balCapitaoBtn">Escolher capitão</button>
      <button class="btn btn-ghost bal-btn" id="balConversaBtn" ${conv.ok ? "" : "disabled"} title="${conv.ok ? "Falar com o grupo" : `Podes voltar a falar com o grupo daqui a ${conv.dias} dia${conv.dias === 1 ? "" : "s"}`}">Conversa de grupo</button>
    </div>
    ${ultima ? `<div class="bal-last helptext">Última conversa (${fmtDateShort(ultima.data)}): ${escapeHtml(ultima.texto)}</div>` : ""}`;
}

function balnearioModalEl() {
  let m = document.getElementById("balnearioModal");
  if (m) return m;
  m = document.createElement("div");
  m.className = "modal-overlay hidden";
  m.id = "balnearioModal";
  m.innerHTML = `<div class="modal-box" style="max-width:560px;"><h3 id="balnearioModalTitle"></h3><div id="balnearioModalBody"></div><div class="modal-actions"><button class="btn btn-ghost" id="balnearioModalClose" style="color:var(--texto);border-color:rgba(0,0,0,0.2);">Fechar</button></div></div>`;
  document.body.appendChild(m);
  m.querySelector("#balnearioModalClose").addEventListener("click", () => m.classList.add("hidden"));
  m.addEventListener("click", e => { if (e.target === m) m.classList.add("hidden"); });
  return m;
}
function openBalnearioCapitaoModal() {
  const mine = myTeam(); const b = ensureBalneario(mine); if (!b) return;
  syncBalnearioPresenca(mine);
  const m = balnearioModalEl();
  const cur = balnearioResolverCapitao(mine, b);
  m.querySelector("#balnearioModalTitle").textContent = "Escolher capitão";
  const squad = balnearioSquad(mine).slice().sort((x, y) => balnearioLeaderScore(b, y) - balnearioLeaderScore(b, x));
  const rows = squad.map(p => {
    const anos = balnearioTenureYears(b, p);
    const tempo = anos < 0.5 ? "recém-chegado" : anos < 1.5 ? "1 época no clube" : `${Math.round(anos)} épocas no clube`;
    const lid = p.attrs && p.attrs.lideranca != null ? p.attrs.lideranca : 10;
    const isCur = cur.player && cur.player.id === p.id && !cur.auto;
    return `<div class="internal-player-row"><div><b>${playerNameHtml(p)}</b><div class="meta">${p.age} anos · ${linhaAbbrev(p)} · Liderança ${lid} · ${tempo}</div></div><div>OVR ${overall(p)}</div><button class="btn ${isCur ? "btn-primary" : "btn-ghost"} bal-set-cap" data-id="${p.id}" ${isCur ? "disabled" : ""}>${isCur ? "Capitão" : "Nomear"}</button></div>`;
  }).join("");
  m.querySelector("#balnearioModalBody").innerHTML = `<p class="helptext" style="margin-bottom:8px;">O capitão pesa no ambiente do balneário e na forma como o grupo reage às crises. Quem perde a braçadeira fica ligeiramente descontente. Os jogadores estão ordenados pela influência natural no grupo.</p>
    <div style="max-height:46vh;overflow:auto;">${rows}</div>
    <div style="margin-top:8px;"><button class="btn btn-ghost" id="balCapAuto" ${cur.auto ? "disabled" : ""}>Deixar automático</button></div>`;
  m.classList.remove("hidden");
}
function openBalnearioConversaModal() {
  const mine = myTeam(); const b = ensureBalneario(mine); if (!b) return;
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = "Conversa de grupo";
  m.querySelector("#balnearioModalBody").innerHTML = `<p class="helptext" style="margin-bottom:10px;">Reúnes o plantel antes do treino. O resultado depende do tom que escolheres, da fase da equipa e do peso do capitão — e pode correr mal. Só podes voltar a fazê-lo passadas três semanas.</p>
    <div class="bal-tons">
      <button class="btn btn-ghost bal-tom" data-tom="uniao"><b>Apelar à união</b><br><span class="helptext">Funciona melhor quando o grupo está tenso.</span></button>
      <button class="btn btn-ghost bal-tom" data-tom="exigir"><b>Exigir mais</b><br><span class="helptext">Ajuda depois de maus resultados; arrisca-se quando se ganha.</span></button>
      <button class="btn btn-ghost bal-tom" data-tom="elogiar"><b>Elogiar o grupo</b><br><span class="helptext">Funciona em boas fases; soa vazio nas más.</span></button>
    </div><div id="balConversaResultado" style="margin-top:10px;"></div>`;
  m.classList.remove("hidden");
}
(function wireBalnearioUi() {
  document.addEventListener("click", e => {
    const t = e.target;
    if (!t || !t.closest) return;
    if (t.closest("#balCapitaoBtn")) { openBalnearioCapitaoModal(); return; }
    if (t.closest("#balConversaBtn")) { openBalnearioConversaModal(); return; }
    const set = t.closest(".bal-set-cap");
    if (set) {
      const r = setBalnearioCapitao(myTeam(), set.getAttribute("data-id"));
      if (r.ok) { balnearioModalEl().classList.add("hidden"); renderBalnearioPanel(); if (typeof renderRoster === "function") renderRoster(); showTransientNotice(r.capitao ? `${r.capitao.name} é o novo capitão.` : "Capitão atualizado."); }
      else showTransientNotice(r.reason);
      return;
    }
    if (t.closest("#balCapAuto")) {
      setBalnearioCapitao(myTeam(), null);
      balnearioModalEl().classList.add("hidden"); renderBalnearioPanel(); if (typeof renderRoster === "function") renderRoster();
      showTransientNotice("O capitão passa a ser escolhido automaticamente.");
      return;
    }
    const tom = t.closest(".bal-tom");
    if (tom) {
      const r = balnearioConversaDeGrupo(myTeam(), tom.getAttribute("data-tom"));
      const out = document.getElementById("balConversaResultado");
      if (!r.ok) { if (out) out.innerHTML = `<div class="helptext">${escapeHtml(r.reason)}</div>`; return; }
      document.querySelectorAll("#balnearioModal .bal-tom").forEach(b => { b.disabled = true; });
      if (out) out.innerHTML = `<div class="pm-postmatch-grid"><div>${escapeHtml(r.texto)}</div></div>`;
      renderBalnearioPanel();
    }
  });
})();
