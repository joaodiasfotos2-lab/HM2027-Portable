// Relatórios do staff em formato de documento (2026-10-12, pedido do utilizador: "os relatórios são
// de difícil leitura, massudos; deviam ser tipo um pdf com o símbolo do clube").
//
// Componente partilhado repDoc(): folha clara com cabeçalho (emblema do clube, departamento,
// título, subtítulo e adversário), faixa de indicadores-chave, "Em resumo" de uma ou duas linhas,
// secções curtas com ícone (linhas rótulo/valor) e blocos de detalhe que se abrem. Aplicado a
// todos os relatórios de tipo "tatica" do adjunto e da análise do adversário, e aos relatórios
// mensais dos emprestados. As notícias continuam a ser HTML guardado no save: nada de novo para
// migrar, só o HTML gerado passa a ser este. Para a pré-visualização na lista de emails, o
// documento leva um <span class="rep-prev"> escondido com o resumo em texto simples.

function repCrestHtml(teamId, px) {
  px = px || 52;
  const team = state.teams && state.teams[teamId];
  if (!team) return `<span class="rep-crest" style="width:${px}px;height:${px}px;"></span>`;
  const url = typeof clubCrestUrl === "function" ? clubCrestUrl(teamId) : null;
  if (url) return `<span class="rep-crest" style="width:${px}px;height:${px}px;"><img src="${url}" alt="" style="width:100%;height:100%;object-fit:contain;"></span>`;
  const cor = typeof clubDisplayColor === "function" ? clubDisplayColor(team) : "#164fb8";
  const ini = typeof clubBadgeInitials === "function" ? clubBadgeInitials(team.name) : String(team.name || "?").slice(0, 3).toUpperCase();
  const txt = typeof clubTextColor === "function" ? clubTextColor(team, cor) : "#fff";
  return `<span class="rep-crest rep-crest-cor" style="width:${px}px;height:${px}px;background:${cor};color:${txt};font-size:${Math.round(px * 0.3)}px;">${escapeHtml(ini)}</span>`;
}
// Resultados "V-E-D" como pequenas pastilhas coloridas (mais recente primeiro/ordem dada).
function repFormaHtml(lista) {
  const arr = Array.isArray(lista) ? lista : String(lista || "").split("-").filter(Boolean);
  if (!arr.length) return "—";
  return arr.map(r => `<span class="rep-forma rep-forma-${r}">${r}</span>`).join("");
}
function repChip(txt, tom) { return { txt, tom: tom || "" }; }
function repTextoSimples(html) { return String(html || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(); }

// o: { teamId, org, titulo, sub, vsId, vsTexto, chips[], resumo, secoes[], detalhes[], rodape }
// secção: { icone, titulo, linhas:[[rótulo, valorHtml]], texto, cheia }
function repDoc(o) {
  const team = state.teams && state.teams[o.teamId];
  const cor = team && typeof clubDisplayColor === "function" ? clubDisplayColor(team) : "#164fb8";
  const org = `${team ? escapeHtml(team.name) : ""}${o.org ? ` · ${escapeHtml(o.org)}` : ""}`;
  const prev = repTextoSimples(o.resumo) || repTextoSimples(o.titulo);
  const vs = o.vsId && state.teams[o.vsId]
    ? `<div class="rep-vs">${repCrestHtml(o.vsId, 40)}<span>${o.vsTexto ? escapeHtml(o.vsTexto) : "vs"}<br><b>${escapeHtml(state.teams[o.vsId].name)}</b></span></div>` : "";
  const chips = (o.chips || []).length ? `<div class="rep-chips">${o.chips.map(c => `<span class="rep-chip ${c.tom ? "rep-chip-" + c.tom : ""}">${c.txt}</span>`).join("")}</div>` : "";
  const resumo = o.resumo ? `<div class="rep-resumo"><span class="rep-rl">Em resumo</span> ${o.resumo}</div>` : "";
  const secoes = (o.secoes || []).filter(s => s && ((s.linhas && s.linhas.length) || s.texto)).map(s => {
    const linhas = (s.linhas || []).filter(l => l && l[1] != null && l[1] !== "").map(l => `<div class="rep-row"><dt>${l[0]}</dt><dd>${l[1]}</dd></div>`).join("");
    return `<section class="rep-sec${s.cheia ? " rep-sec-cheia" : ""}"><h4>${s.icone ? `<span class="rep-ico">${s.icone}</span>` : ""}${s.titulo}</h4>${linhas ? `<dl>${linhas}</dl>` : ""}${s.texto ? `<p>${s.texto}</p>` : ""}</section>`;
  }).join("");
  const detalhes = (o.detalhes || []).filter(d => d && d.html).map(d => `<details class="rep-det"><summary>${d.titulo}</summary><div>${d.html}</div></details>`).join("");
  return `<div class="rep-doc" style="--rep-cor:${cor};"><span class="rep-prev">${escapeHtml(prev)}</span>
    <div class="rep-head">${repCrestHtml(o.teamId, 56)}
      <div class="rep-head-t"><div class="rep-org">${org}</div><div class="rep-title">${o.titulo}</div>${o.sub ? `<div class="rep-sub">${o.sub}</div>` : ""}</div>${vs}</div>
    ${chips}${resumo}
    ${secoes ? `<div class="rep-grid">${secoes}</div>` : ""}${detalhes}
    <div class="rep-foot">${o.rodape || "Documento interno do departamento técnico"}</div></div>`;
}
// Linhas em HTML (separadas por <br>) -> valor limpo, sem <br> finais.
function repLimpaBr(html) { return String(html || "").replace(/(<br\s*\/?>\s*)+$/i, "").trim(); }

// ---------------------------------------------------------------------------------------------
// Relatório de scouting em formato folha (2026-10-12). Usa o dossiê já existente (6 parágrafos
// gerados por buildScoutingDossier) distribuído por secções, mais uma ficha-resumo guardada no
// relatório (idade, posição, OVR estimado e potencial no momento da observação).
// ---------------------------------------------------------------------------------------------
function repScoutingFicha(r) {
  if (r.ficha) return r.ficha;
  const tid = typeof locateScoutedPlayerTeamId === "function" ? locateScoutedPlayerTeamId(r.playerId, r.targetTeamId) : null;
  const team = tid ? state.teams[tid] : null;
  const p = team ? (team.players || []).find(x => x.id === r.playerId) : null;
  if (!p) return null;
  const f = { idade: p.age, pos: scoutingPositionLabel(p), ovr: Math.round(visibleOverall(p, team)), pot: visiblePotentialLabel(p, team), divisao: scoutingDivisionLabel(team.divisaoAtual) };
  r.ficha = f;
  return f;
}
function repScoutingDoc(r, paragrafos) {
  const my = myTeam();
  const liveTeamId = typeof locateScoutedPlayerTeamId === "function" ? locateScoutedPlayerTeamId(r.playerId, r.targetTeamId) : null;
  const player = liveTeamId ? (state.teams[liveTeamId].players || []).find(p => p.id === r.playerId) : null;
  const vsId = r.targetTeamId && state.teams[r.targetTeamId] ? r.targetTeamId : liveTeamId;
  const f = repScoutingFicha(r) || {};
  const rapido = r.tipo === "rapido";
  const ps = (paragrafos || []).filter(Boolean);
  const cap = t => { t = String(t || ""); return t.charAt(0) === "<" ? t : t.charAt(0).toUpperCase() + t.slice(1); };
  const tira = (txt, rot) => cap(String(txt || "").replace(new RegExp("^" + rot + "\\s*"), ""));
  const acha = rot => ps.find(x => String(x).startsWith(rot));
  const abertura = ps[0], analise = ps[1], comparacao = ps[2];
  const potencial = acha("Potencial de evolução:"), recom = acha("Recomendação:"), pers = acha("Personalidade:");
  const recTxt = recom ? tira(recom, "Recomendação:") : "";
  const recLow = recTxt.toLowerCase();
  const tom = /reforço claro|reforço a considerar|pronto para reforçar|rotação sólido/.test(recLow) ? ["Reforço recomendado", "ok"]
    : /rotação, não|muito parecido|perfil limitado/.test(recLow) ? ["Só rotação", "aviso"] : ["Não recomendado", "mau"];
  const resumo = recTxt.replace(/\s*Conclusão preliminar.*$/, "");
  const nome = player && liveTeamId ? playerLinkHtml(liveTeamId, player) : escapeHtml(r.playerName || "Jogador");
  const chips = [];
  if (f.pos) chips.push(repChip(f.pos));
  if (f.idade != null) chips.push(repChip(`${f.idade} anos`));
  if (f.ovr != null) chips.push(repChip(`OVR ${f.ovr} (est.)`));
  if (f.pot) chips.push(repChip(`Potencial ${String(f.pot).toLowerCase()}`));
  if (f.divisao) chips.push(repChip(f.divisao));
  chips.push(repChip(tom[0], tom[1]));
  return repDoc({
    teamId: my ? my.id : r.targetTeamId, org: "Departamento de scouting", titulo: rapido ? "Relatório de scouting (rápido)" : "Relatório de scouting (completo)",
    sub: `${nome}${r.targetTeamName ? ` · ${escapeHtml(r.targetTeamName)}` : ""} · ${fmtDateLong(new Date(r.resolvedDate))}`,
    vsId, vsTexto: "observado em",
    chips,
    resumo: resumo || undefined,
    secoes: [
      { icone: "👤", titulo: "Perfil", texto: abertura },
      { icone: "⚖️", titulo: "Pontos fortes e fracos", texto: analise },
      { icone: "📊", titulo: "Comparação com a divisão", texto: comparacao },
      { icone: "📈", titulo: "Potencial de evolução", texto: tira(potencial, "Potencial de evolução:") },
      pers ? { icone: "🧠", titulo: "Personalidade", texto: tira(pers, "Personalidade:") } : null,
      { icone: "🎯", titulo: "Recomendação para o teu clube", cheia: true, texto: recTxt },
    ].filter(Boolean),
    rodape: `Relatório ${rapido ? "rápido" : "completo"} de scouting · departamento de scouting`,
  });
}
