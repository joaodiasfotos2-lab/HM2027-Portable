// Análise do adversário (2026-10-12, pedido do utilizador: ideia 1 da décima lista).
// Decisões de desenho confirmadas por ele:
//  - o relatório do analista traz: padrões táticos, jogadores-chave e pontos fracos, bolas
//    paradas e disciplina, forma recente e histórico direto;
//  - antes do jogo escolhes até 2 CONTRAMEDIDAS; se acertarem no padrão real do adversário dão
//    um pequeno bónus, se falharem o alvo custam um pequeno prejuízo;
//  - a fiabilidade do relatório depende do departamento de análise (4 níveis), do tempo que
//    há até ao jogo e de jogos seguidos; cada relatório custa dinheiro e demora alguns dias;
//  - a IA também se prepara contra ti e contra os outros adversários.
//
// O RGHP não fala de análise de vídeo: todos os valores numéricos são ESTIMATIVAS (qualidade
// por nível, prazos, custos, tamanho dos bónus de 3%, penalização de 1%, probabilidades de a
// IA se preparar). Só o clube do utilizador paga o departamento (a IA tem-no "incluído" e sem
// custo, para não mexer na calibração financeira).
//
// Dados globais em state.analise (guardado com o jogo):
//   relatorios  { "<data>|<adversário>": relatório }   relatórios prontos
//   pedidos     [ { key, oppId, data, pedidoEm, pronta, apressada, custo } ]   em curso
//   escolhas    { "<data>|<adversário>": [ids de contramedidas] }
//   historico   [ { ... } ]  verificação depois de cada jogo (contramedidas e relatório)
// Equipa: team.analise = { nivel, gerido }.

const ANA_NIVEIS = {
  0: { label: "Só o adjunto",            qual: 0.38, dias: 4, mensal: 0,    custoRel: 150 },
  1: { label: "Analista de vídeo",       qual: 0.55, dias: 3, mensal: 0.05, custoRel: 350 },
  2: { label: "Departamento de análise", qual: 0.74, dias: 2, mensal: 0.12, custoRel: 700 },
  3: { label: "Análise de elite",        qual: 0.90, dias: 1, mensal: 0.22, custoRel: 1200 },
};
const ANA_MAX_NIVEL = 3;
const ANA_DIV_FATOR = { 3: 1, 2: 0.4, 1: 0.15 };    // custo dos relatórios por escalão
const ANA_BONUS = 0.03;                              // bónus máximo de uma contramedida certeira
const ANA_PENALIZACAO = 0.01;                        // prejuízo de uma contramedida que falha o alvo
const ANA_MAX_ESCOLHAS = 2;
const ANA_IA_PROB = { 0: 0.25, 1: 0.45, 2: 0.65, 3: 0.85 };   // probabilidade de a IA se preparar para um jogo
const ANA_REL_MIN = 0.35;                            // relevância mínima para o relatório sugerir uma contramedida

// Perfil de um adversário: { pressao, mentalidade, sistema, grTaxa 0–1, dependencia 0–1, bpAmeaca 0–1 }.
// tipo: att = bónus à conversão própria; def = reduz a conversão do adversário; sp = reduz a
// conversão do adversário em bolas paradas; gr = só atua quando um dos guarda-redes sai.
const ANA_CM = {
  circulacao: {
    label: "Circulação paciente", tipo: "att",
    texto: "Saída de bola curta e paciente para furar a pressão alta do adversário.",
    rel: p => p.pressao === "alta" ? 1 : p.pressao === "media" ? 0.25 : 0,
  },
  meia_distancia: {
    label: "Remate de longe", tipo: "att",
    texto: "Mais remates de meia distância contra um bloco recuado.",
    rel: p => Math.max(p.pressao === "baixa" ? 1 : p.pressao === "media" ? 0.15 : 0, p.mentalidade === "defensivo" ? 0.7 : 0),
  },
  transicao: {
    label: "Transição rápida", tipo: "att",
    texto: "Atacar depressa o espaço que uma equipa ofensiva deixa nas costas.",
    rel: p => Math.min(1, (p.mentalidade === "ofensivo" ? 0.8 : p.mentalidade === "equilibrado" ? 0.2 : 0) + (p.pressao === "alta" ? 0.2 : 0)),
  },
  marcar_chave: {
    label: "Marcação ao jogador-chave", tipo: "def",
    texto: "Dobrar a marcação ao jogador de que o adversário mais depende.",
    rel: p => p.dependencia,
  },
  bolas_paradas: {
    label: "Bolas paradas defensivas", tipo: "sp",
    texto: "Treino específico para defender livres diretos e penáltis do adversário.",
    rel: p => p.bpAmeaca,
  },
  anti_gr: {
    label: "Preparar o 5 contra 4", tipo: "gr",
    texto: "Rotinas para defender quando o adversário tira o guarda-redes (e para atacar a baliza vazia quando o faz).",
    rel: p => Math.min(1, p.grTaxa / 0.5),
  },
};
const ANA_CM_IDS = Object.keys(ANA_CM);

function anaEnsure(){
  if(!state.analise || typeof state.analise !== "object") state.analise = { v: 1, relatorios: {}, pedidos: [], escolhas: {}, historico: [], ultimoRelatorio: null };
  const a = state.analise;
  if(!a.relatorios) a.relatorios = {};
  if(!Array.isArray(a.pedidos)) a.pedidos = [];
  if(!a.escolhas) a.escolhas = {};
  if(!Array.isArray(a.historico)) a.historico = [];
  return a;
}
function anaHoje(){ return isoDate(state.currentDate || new Date()); }
function anaDias(aIso, bIso){ return Math.round((new Date(bIso) - new Date(aIso)) / 86400000); }
function anaGauss(){
  const u1 = Math.max(1e-9, Math.random()), u2 = Math.random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

// ---------------------------------------------------------------- departamento
function anaNivelPadrao(team){
  const rep = team.reputacaoClube != null ? team.reputacaoClube : (team.reputacao != null ? team.reputacao : 50);
  let n = rep >= 92 ? 3 : rep >= 80 ? 2 : rep >= 55 ? 1 : 0;
  if(team.divisaoAtual === "3div") n = 0;
  else if(team.divisaoAtual === "2div") n = Math.min(n, 1);
  return n;
}
function anaDono(team){ return team && team.equipaPrincipalId && state.teams[team.equipaPrincipalId] ? state.teams[team.equipaPrincipalId] : team; }
function anaDept(team){
  const dono = anaDono(team);
  if(!dono) return { nivel: 0, gerido: false };
  if(!dono.analise || typeof dono.analise !== "object") dono.analise = { nivel: anaNivelPadrao(dono), gerido: false };
  if(!Number.isFinite(dono.analise.nivel)) dono.analise.nivel = anaNivelPadrao(dono);
  if(!dono.analise.gerido && !isUserControlledTeam(dono)) dono.analise.nivel = anaNivelPadrao(dono);
  dono.analise.nivel = clamp(Math.round(dono.analise.nivel), 0, ANA_MAX_NIVEL);
  return dono.analise;
}
function anaNivel(team){ return anaDept(team).nivel; }
function anaCfg(team){ return ANA_NIVEIS[anaNivel(team)]; }
function anaCustoMensal(team){ return Math.round(avgMonthlySalary(team) * anaCfg(team).mensal / 10) * 10; }
function anaCustoRelatorio(team){
  return Math.round(anaCfg(team).custoRel * (ANA_DIV_FATOR[teamDivisionRank(team)] || 0.15) / 10) * 10;
}
function anaCustoSubida(team, nivel){
  const atual = ANA_NIVEIS[anaNivel(team)].mensal, novo = ANA_NIVEIS[nivel].mensal;
  return Math.max(800, Math.round(avgMonthlySalary(team) * (novo - atual) * 6 / 10) * 10);
}
function anaMudarNivel(nivel){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  nivel = clamp(Math.round(nivel), 0, ANA_MAX_NIVEL);
  const d = anaDept(team);
  if(nivel === d.nivel) return { ok: false, reason: "O departamento já está nesse nível." };
  if(nivel > d.nivel){
    initClubFinance(team);
    const custo = anaCustoSubida(team, nivel);
    if((team.financeiro.saldo || 0) < custo) return { ok: false, reason: `Saldo insuficiente (custo de instalação ${fmtMoney(custo)}).` };
    addFinanceMovement(team, "despesa", "Análise do adversário", `Instalação do departamento de análise (${ANA_NIVEIS[nivel].label})`, custo, new Date(state.currentDate));
  }
  d.nivel = nivel; d.gerido = true;
  return { ok: true };
}
function anaMensal(date){
  Object.values(state.teams).forEach(team => {
    if(team.equipaPrincipalId || !isUserControlledTeam(team)) return;
    const c = anaCustoMensal(team);
    if(c > 0) addFinanceMovement(team, "despesa", "Análise do adversário", "Encargos mensais do departamento de análise", c, date);
  });
}

// ---------------------------------------------------------------- próximo jogo
function anaProximoJogo(){
  if(!state.userTeamId || typeof myFullSchedule !== "function") return null;
  const hoje = anaHoje();
  let rows;
  try { rows = myFullSchedule().filter(r => !r.played && r.date && isoDate(r.date) >= hoje); } catch(e){ return null; }
  const r = rows[0]; if(!r) return null;
  const data = isoDate(r.date);
  return { key: `${data}|${r.oppId}`, data, oppId: r.oppId, competicao: r.competicao, local: r.local, dias: anaDias(hoje, data) };
}
// Relatório/escolhas de um jogo concreto (data + adversário); aceita 1 dia de folga para
// diferenças de hora entre o calendário e a data corrente.
function anaChaveDoJogo(oppId, dataIso){
  const A = anaEnsure();
  const direta = `${dataIso}|${oppId}`;
  if(A.relatorios[direta] || A.escolhas[direta] || A.pedidos.some(p => p.key === direta)) return direta;
  for(const off of [-1, 1]){
    const d = isoDate(addDays(new Date(dataIso), off));
    const k = `${d}|${oppId}`;
    if(A.relatorios[k] || A.escolhas[k] || A.pedidos.some(p => p.key === k)) return k;
  }
  return direta;
}

// ---------------------------------------------------------------- perfil do adversário
function anaModo(hist, campo, def){
  const cont = {};
  hist.forEach(h => { const v = h[campo]; if(v) cont[v] = (cont[v] || 0) + 1; });
  const chaves = Object.keys(cont).sort((a, b) => cont[b] - cont[a]);
  if(!chaves.length) return { val: def, pct: null, n: 0 };
  return { val: chaves[0], pct: Math.round(cont[chaves[0]] / hist.length * 100), n: hist.length };
}
function anaGrTaxa(team){
  const h = (team.historicoTatico || []).slice(0, 20).filter(x => x.grPuxado != null);
  const g = h.filter(x => x.grPuxado > 0).length;
  return (g + 0.6) / (h.length + 2);      // prior de 30% quando há poucos dados
}
function anaDependencia(team){
  const o = (team.players || []).filter(p => p.pos === "J").map(p => overall(p)).sort((a, b) => b - a).slice(0, 5);
  if(o.length < 3) return 0.3;
  return clamp((o[0] - avg(o.slice(1))) / 4, 0, 1);
}
function anaBp(team){
  const cands = (team.players || []).filter(p => p.pos === "J" && playerAvailableForMatch(p));
  const score = p => 0.75 * ((p.attrs && p.attrs.bolasParadas) || 10) + 0.25 * ((p.attrs && p.attrs.determinacao) || 10);
  cands.sort((a, b) => score(b) - score(a));
  const top = cands[0];
  return { jogador: top || null, ameaca: top ? clamp((score(top) - 12) / 5, 0, 1) : 0.3, score: top ? score(top) : 10 };
}
function anaGr(team){
  const gr = (team.players || []).filter(p => p.pos === "GR").sort((a, b) => overall(b) - overall(a))[0];
  if(!gr) return { jogador: null, valor: 12 };
  return { jogador: gr, valor: (((gr.attrs && gr.attrs.reflexos) || 10) + ((gr.attrs && gr.attrs.umParaUm) || 10)) / 2 };
}
// Perfil "real" usado no jogo. Para equipas de IA usa as opções tomadas para este jogo; para o
// clube do utilizador (cujas opções só são repostas depois de newMatchState) usa o hábito.
function anaPerfilReal(team){
  const h = (team.historicoTatico || []).slice(0, 10);
  const user = isUserControlledTeam(team);
  return {
    pressao: user ? anaModo(h, "pressao", team.identidadePressaoPreferencial || "media").val : (team.pressao || "media"),
    mentalidade: user ? anaModo(h, "mentalidade", team.identidadeMentalidadePreferencial || "equilibrado").val : (team.mentalidade || "equilibrado"),
    sistema: user ? anaModo(h, "sistema", team.identidadeSistemaPrincipal || "3-1").val : (team.sistema || "3-1"),
    grTaxa: anaGrTaxa(team),
    dependencia: anaDependencia(team),
    bpAmeaca: anaBp(team).ameaca,
  };
}

// ---------------------------------------------------------------- qualidade do relatório
function anaQualidade(team, oppId, apressada){
  const cfg = anaCfg(team);
  let q = cfg.qual;
  if(isUserControlledTeam(team) && state.gestor && Number.isFinite(state.gestor.reputacao)) q += (state.gestor.reputacao - 50) * 0.0015;
  const hoje = anaHoje();
  if(apressada) q -= 0.15;
  try {
    const rec = myFullSchedule().filter(r => r.played && r.date && anaDias(isoDate(r.date), hoje) >= 0 && anaDias(isoDate(r.date), hoje) <= 3);
    if(rec.length) q -= 0.08;          // jogos seguidos: a equipa técnica está ocupada
  } catch(e){}
  const A = anaEnsure();
  if(A.ultimoRelatorio && anaDias(A.ultimoRelatorio, hoje) <= 3) q -= 0.06;
  const opp = state.teams[oppId];
  if(opp && typeof viagemPais === "function" && viagemPais(opp) !== viagemPais(team)) q -= 0.05;   // menos dados de outro país
  if(opp && (opp.historicoTatico || []).length < 3) q -= 0.08;                                       // quase sem jogos para analisar
  return clamp(q, 0.2, 0.97);
}
function anaFiabilidade(q){ return q >= 0.8 ? "Alta" : q >= 0.55 ? "Média" : "Baixa"; }
function anaAcerta(q){ return Math.random() < 0.5 + 0.5 * q; }
function anaRuido(valor, q, escala, min, max){
  return clamp(valor + anaGauss() * (1 - q) * escala, min, max);
}
function anaNivelLabel(v){ return v >= 0.65 ? "alta" : v >= 0.3 ? "moderada" : "baixa"; }
function anaMediaLiga(oppId){
  const todos = [];
  Object.values(state.teams).forEach(t => { (t.historicoTatico || []).slice(0, 10).forEach(h => { if(h.remates) todos.push(h.remates); }); });
  return todos.length > 20 ? avg(todos) : 25;
}
const ANA_LABEL_PRESSAO = { baixa: "baixa", media: "média", alta: "alta" };
const ANA_LABEL_MENTALIDADE = { defensivo: "defensiva", equilibrado: "equilibrada", ofensivo: "ofensiva" };

// ---------------------------------------------------------------- relatório
function anaConstruir(team, opp, pedido){
  const q = anaQualidade(team, opp.id, pedido.apressada);
  const lvl = anaNivel(team);
  const h10 = (opp.historicoTatico || []).slice(0, 10);
  const rel = { key: pedido.key, oppId: opp.id, data: pedido.data, local: pedido.local, competicao: pedido.competicao, geradoEm: anaHoje(), q, nivel: lvl, apressada: !!pedido.apressada };

  // 1) padrões táticos
  const mSis = anaModo(h10, "sistema", opp.identidadeSistemaPrincipal || "3-1");
  const mPre = anaModo(h10, "pressao", opp.identidadePressaoPreferencial || "media");
  const mMen = anaModo(h10, "mentalidade", opp.identidadeMentalidadePreferencial || "equilibrado");
  const trocar = (val, opcoes) => anaAcerta(q) ? val : opcoes.filter(o => o !== val)[Math.floor(Math.random() * (opcoes.length - 1))];
  const pad = { n: h10.length };
  pad.sistema = trocar(mSis.val, ["3-1", "2-2"]);
  pad.sistemaPct = mSis.pct == null ? null : Math.round(anaRuido(mSis.pct, q, 25, 30, 100) / 5) * 5;
  pad.pressao = trocar(mPre.val, ["baixa", "media", "alta"]);
  pad.mentalidade = trocar(mMen.val, ["defensivo", "equilibrado", "ofensivo"]);
  const gr = anaGrTaxa(opp);
  pad.grTaxa = q >= 0.45 ? anaRuido(gr, q, 0.25, 0, 1) : null;
  const remates = h10.filter(h => h.remates != null);
  if(remates.length >= 3){
    const rel2 = avg(remates.map(h => h.remates)) / anaMediaLiga(opp.id) * (1 + anaGauss() * (1 - q) * 0.2);
    pad.volume = rel2 > 1.1 ? "alto" : rel2 < 0.9 ? "baixo" : "médio";
  } else pad.volume = null;
  rel.padroes = pad;

  // 2) jogadores-chave e pontos fracos
  const outfield = (opp.players || []).filter(p => p.pos === "J");
  const maxGolos = Math.max(1, ...outfield.map(p => (p.season && p.season.golos) || 0));
  const ranking = outfield.slice().sort((a, b) => (overall(b) + 1.5 * ((b.season && b.season.golos) || 0) / maxGolos) - (overall(a) + 1.5 * ((a.season && a.season.golos) || 0) / maxGolos));
  const chave = { };
  if(ranking.length){
    const escolhido = anaAcerta(q) ? ranking[0] : (ranking[1 + Math.floor(Math.random() * Math.min(2, ranking.length - 1))] || ranking[0]);
    chave.playerId = escolhido.id; chave.nome = escolhido.name;
    chave.dependencia = anaRuido(anaDependencia(opp), q, 0.35, 0, 1);
  }
  const grInfo = anaGr(opp);
  if(q >= 0.5 && grInfo.jogador){
    const v = anaRuido(grInfo.valor, q, 4, 4, 20);
    chave.gr = v >= 15 ? "de topo" : v >= 12 ? "sólido" : "vulnerável";
    chave.grNome = grInfo.jogador.name; chave.grId = grInfo.jogador.id;
  }
  const fracos = [];
  const titulares = outfield.filter(p => p.titular);
  const base = titulares.length ? titulares : outfield.slice(0, 4);
  const cond = base.length ? avg(base.map(p => p.condicao != null ? p.condicao : 100)) : 100;
  const defs = outfield.filter(p => p.linha !== "Avancado");
  const defVal = defs.length ? avg(defs.map(p => (((p.attrs && p.attrs.desarme) || 10) + ((p.attrs && p.attrs.posicionamento) || 10)) / 2)) : 10;
  const disp = outfield.filter(p => playerAvailableForMatch(p)).length;
  const talvez = real => real ? Math.random() < 0.55 + 0.45 * q : Math.random() < (1 - q) * 0.12;
  if(talvez(cond < 80)) fracos.push("equipa desgastada fisicamente");
  if(talvez(defVal < 11.5)) fracos.push("defesa frágil");
  if(talvez(disp < 6)) fracos.push("banco curto");
  rel.chave = chave; rel.fracos = fracos;

  // 3) bolas paradas e disciplina (só com departamento capaz)
  if(q >= 0.45){
    const bp = anaBp(opp);
    const top3 = (opp.players || []).filter(p => p.pos === "J" && playerAvailableForMatch(p)).sort((a, b) => (b.attrs.bolasParadas || 0) - (a.attrs.bolasParadas || 0)).slice(0, 3);
    const marcador = bp.jogador && anaAcerta(q) ? bp.jogador : (top3[Math.floor(Math.random() * top3.length)] || bp.jogador);
    rel.bp = { ameaca: anaRuido(bp.ameaca, q, 0.4, 0, 1), jogador: marcador ? marcador.name : null, jogadorId: marcador ? marcador.id : null };
    const jogosReais = (opp.historicoTatico || []).filter(x => x.date && new Date(x.date) >= new Date(2026 + (state.season - 1), 9, 1)).length;
    const cartoes = (opp.players || []).reduce((s, p) => s + ((p.season && (p.season.amarelos || 0) + (p.season.azuis || 0) + (p.season.vermelhos || 0)) || 0), 0);
    if(jogosReais >= 3){
      const porJogo = anaRuido(cartoes / jogosReais, q, 1.2, 0, 12);
      rel.disc = { porJogo, perfil: porJogo > 4 ? "indisciplinada" : porJogo < 2.5 ? "disciplinada" : "normal", amostra: jogosReais };
    } else rel.disc = null;
  } else { rel.bp = null; rel.disc = null; }

  // 4) forma e histórico direto
  const forma = { };
  const nF = q >= 0.45 ? 5 : 3;
  forma.ultimos = h10.slice(0, nF).map(x => x.resultado);
  const ptsF = h10.slice(0, 5).reduce((s, x) => s + (x.resultado === "V" ? 3 : x.resultado === "E" ? 1 : 0), 0);
  forma.pontosJogo = h10.length ? ptsF / Math.min(5, h10.length) : null;
  const golosM = h10.length ? avg(h10.map(x => x.golosMarcados || 0)) : null, golosS = h10.length ? avg(h10.map(x => x.golosSofridos || 0)) : null;
  forma.golos = golosM != null ? { m: golosM, s: golosS } : null;
  if(q >= 0.5){
    const h2h = (opp.historicoTatico || []).filter(x => x.opponentId === team.id).slice(0, 3);
    forma.h2h = h2h.map(x => ({ data: x.date, m: x.golosSofridos, s: x.golosMarcados, res: x.resultado === "V" ? "D" : x.resultado === "D" ? "V" : "E" }));
  } else forma.h2h = null;
  if(q >= 0.65){
    const emCasa = pedido.local === "F";      // se o utilizador visita, o adversário joga em casa
    const sub = h10.filter(x => !!x.isHome === emCasa);
    if(sub.length >= 3) forma.local = { emCasa, v: sub.filter(x => x.resultado === "V").length, e: sub.filter(x => x.resultado === "E").length, d: sub.filter(x => x.resultado === "D").length };
  }
  rel.forma = forma;

  // sugestões: contramedidas com maior relevância segundo o que foi REPORTADO (não a verdade)
  const perfilRep = {
    pressao: pad.pressao, mentalidade: pad.mentalidade, sistema: pad.sistema,
    grTaxa: pad.grTaxa != null ? pad.grTaxa : 0.3,
    dependencia: chave.dependencia != null ? chave.dependencia : 0.3,
    bpAmeaca: rel.bp ? rel.bp.ameaca : 0.3,
  };
  rel.perfilReportado = perfilRep;
  rel.sugeridas = ANA_CM_IDS.map(id => ({ id, r: ANA_CM[id].rel(perfilRep) })).filter(x => x.r >= ANA_REL_MIN).sort((a, b) => b.r - a.r).slice(0, ANA_MAX_ESCOLHAS).map(x => x.id);
  return rel;
}

function anaRelatorioHtml(rel){
  const opp = state.teams[rel.oppId]; if(!opp) return "";
  const p = rel.padroes, f = rel.forma, c = rel.chave;
  const fiab = anaFiabilidade(rel.q);
  const lg = [];
  lg.push(["Sistema", p.n >= 3 ? `<b>${p.sistema}</b>${p.sistemaPct != null ? ` (cerca de ${p.sistemaPct}% dos jogos)` : ""}` : "poucos jogos para identificar um padrão"]);
  lg.push(["Pressão", `<b>${ANA_LABEL_PRESSAO[p.pressao] || "—"}</b>`]);
  lg.push(["Mentalidade", `<b>${ANA_LABEL_MENTALIDADE[p.mentalidade] || "—"}</b>`]);
  if(p.grTaxa != null) lg.push(["Guarda-redes avançado", p.grTaxa >= 0.4 ? "recorre muitas vezes" : p.grTaxa >= 0.2 ? "recorre com frequência normal" : "raramente recorre"]);
  if(p.volume) lg.push(["Remates", `<b>${p.volume}</b>`]);
  const lc = [];
  if(c.nome) lc.push(["Jogador-chave", `<b>${escapeHtml(c.nome)}</b> — dependência do coletivo ${anaNivelLabel(c.dependencia)}`]);
  if(c.gr) lc.push(["Guarda-redes", `${escapeHtml(c.grNome)}: <b>${c.gr}</b>`]);
  lc.push(["Pontos fracos", rel.fracos.length ? rel.fracos.join(", ") : "nada de relevante identificado"]);
  let ld;
  if(rel.bp){
    ld = [["Ameaça", `<b>${anaNivelLabel(rel.bp.ameaca)}</b>${rel.bp.jogador ? ` (batedor provável: ${escapeHtml(rel.bp.jogador)})` : ""}`],
      ["Disciplina", rel.disc ? `equipa <b>${rel.disc.perfil}</b> (cerca de ${rel.disc.porJogo.toFixed(1)} cartões por jogo)` : "poucos jogos esta época para tirar conclusões"]];
  } else ld = [["Bolas paradas", "sem dados fiáveis: este departamento não tem meios para as avaliar"]];
  const lf = [];
  if(f.ultimos.length) lf.push(["Últimos jogos", `${repFormaHtml(f.ultimos)} <span style="color:#8a9097;font-size:12px;">(mais recente à esquerda)</span>`]);
  if(f.golos) lf.push(["Golos por jogo", `${f.golos.m.toFixed(1)} marcados, ${f.golos.s.toFixed(1)} sofridos`]);
  if(f.local) lf.push([f.local.emCasa ? "Em casa" : "Fora", `${f.local.v}V ${f.local.e}E ${f.local.d}D nos jogos analisados`]);
  if(f.h2h) lf.push(["Confrontos diretos", f.h2h.length ? `${f.h2h.map(x => `${x.m}-${x.s}`).join(", ")} (do teu lado)` : "sem registo"]);
  const sug = rel.sugeridas.length ? rel.sugeridas.map(id => ANA_CM[id].label).join(", ") : "";
  const chips = [repChip(`Fiabilidade ${fiab.toLowerCase()}`, fiab === "Alta" ? "ok" : fiab === "Baixa" ? "mau" : "aviso")];
  if(rel.apressada) chips.push(repChip("Análise apressada", "aviso"));
  if(p.n >= 3) chips.push(repChip(`Sistema ${p.sistema}`));
  chips.push(repChip(`Pressão ${(ANA_LABEL_PRESSAO[p.pressao] || "—").toLowerCase()}`));
  return repDoc({
    teamId: state.userTeamId, org: "Departamento de análise", titulo: "Análise do adversário",
    sub: `${teamLinkHtml(opp.id)}${rel.apressada ? " · análise apressada: faltou tempo" : ""}`,
    vsId: opp.id, vsTexto: "adversário",
    chips,
    resumo: sug ? `Contramedidas sugeridas: <b>${sug}</b>. Escolhe-as em Táticas antes do jogo.` : "Sem contramedidas claramente indicadas. Escolhe-as em Táticas antes do jogo, se quiseres.",
    secoes: [
      { icone:"🧩", titulo:"Padrões táticos", linhas: lg },
      { icone:"🎯", titulo:"Jogadores-chave e pontos fracos", linhas: lc },
      { icone:"🚩", titulo:"Bolas paradas e disciplina", linhas: ld },
      { icone:"📊", titulo:"Forma e histórico direto", linhas: lf.length ? lf : [["Dados", "sem dados"]] },
    ],
    rodape: `Análise do adversário · fiabilidade ${fiab.toLowerCase()}`,
  });
}

// ---------------------------------------------------------------- pedidos e geração
function anaPedir(){
  const team = myTeam(); if(!team) return { ok: false, reason: "Sem clube." };
  const A = anaEnsure(), nx = anaProximoJogo();
  if(!nx) return { ok: false, reason: "Não há jogo agendado." };
  if(nx.dias < 1) return { ok: false, reason: "O jogo é hoje: já não há tempo para uma análise." };
  if(A.relatorios[nx.key] || A.pedidos.some(p => p.key === nx.key)) return { ok: false, reason: "Já pediste a análise deste jogo." };
  initClubFinance(team);
  const custo = anaCustoRelatorio(team);
  if((team.financeiro.saldo || 0) < custo) return { ok: false, reason: `Saldo insuficiente (custo ${fmtMoney(custo)}).` };
  const cfg = anaCfg(team), opp = state.teams[nx.oppId];
  const apressada = nx.dias < cfg.dias;
  const prazo = Math.min(cfg.dias, nx.dias);
  const hoje = anaHoje();
  addFinanceMovement(team, "despesa", "Análise do adversário", `Análise ao ${opp ? opp.name : "adversário"}`, custo, new Date(state.currentDate));
  A.pedidos.push({ key: nx.key, oppId: nx.oppId, data: nx.data, local: nx.local, competicao: nx.competicao, pedidoEm: hoje, pronta: isoDate(addDays(new Date(hoje), prazo)), apressada, custo });
  return { ok: true, prazo, apressada, custo };
}
function anaGerar(pedido){
  const team = myTeam(), opp = state.teams[pedido.oppId];
  if(!team || !opp) return null;
  const A = anaEnsure();
  const rel = anaConstruir(team, opp, pedido);
  A.relatorios[pedido.key] = rel;
  A.ultimoRelatorio = anaHoje();
  pushNews(state.currentDate, anaRelatorioHtml(rel), "tatica", `Análise do adversário: ${opp.name}`, { autoAdvanceStop: true });
  return rel;
}
function anaDiario(){
  const A = anaEnsure(); if(!A.pedidos.length) return;
  const hoje = anaHoje();
  const restantes = [];
  A.pedidos.forEach(p => {
    if(p.data < hoje) return;                         // o jogo já passou sem relatório: perde-se
    if(p.pronta <= hoje) anaGerar(p); else restantes.push(p);
  });
  A.pedidos = restantes;
  // limpa o que já passou há muito
  Object.keys(A.relatorios).forEach(k => { if(anaDias(k.split("|")[0], hoje) > 30) delete A.relatorios[k]; });
  Object.keys(A.escolhas).forEach(k => { if(anaDias(k.split("|")[0], hoje) > 30) delete A.escolhas[k]; });
}

// ---------------------------------------------------------------- contramedidas
function anaEscolher(ids){
  const nx = anaProximoJogo(); if(!nx) return { ok: false, reason: "Não há jogo agendado." };
  const A = anaEnsure();
  const lista = (ids || []).filter(id => ANA_CM[id]).slice(0, ANA_MAX_ESCOLHAS);
  if(lista.length) A.escolhas[nx.key] = lista; else delete A.escolhas[nx.key];
  return { ok: true, ids: lista };
}
function anaEscolhasDoJogo(oppId){
  const A = anaEnsure();
  const k = anaChaveDoJogo(oppId, anaHoje());
  return { key: k, ids: A.escolhas[k] || [], relatorio: A.relatorios[k] || null };
}
// efeitos de uma lista de contramedidas contra um perfil real
function anaEfeitos(ids, perfil){
  const e = { conv: 1, convSof: 1, sp: 1, grDef: 1, grAtk: 1, detalhe: [] };
  ids.forEach(id => {
    const cm = ANA_CM[id]; if(!cm) return;
    const r = cm.rel(perfil);
    if(cm.tipo === "att") e.conv *= 1 + ANA_BONUS * r - (r < 0.2 ? ANA_PENALIZACAO : 0);
    else if(cm.tipo === "def") e.convSof *= 1 - ANA_BONUS * r + (r < 0.2 ? ANA_PENALIZACAO : 0);
    else if(cm.tipo === "sp") e.sp *= 1 - 0.10 * r + (r < 0.2 ? 0.03 : 0);
    else if(cm.tipo === "gr"){ e.grDef = 0.85; e.grAtk = 1.15; }
    e.detalhe.push({ id, rel: r });
  });
  e.conv = clamp(e.conv, 0.97, 1.06); e.convSof = clamp(e.convSof, 0.94, 1.03); e.sp = clamp(e.sp, 0.88, 1.04);
  return e;
}
// A IA prepara-se: escolhe a contramedida mais relevante segundo o que PERCEBE (com ruído).
function anaIaEscolhe(team, oppPerfil){
  const nivel = anaNivel(team), q = ANA_NIVEIS[nivel].qual;
  if(Math.random() > ANA_IA_PROB[nivel]) return [];
  const perc = {
    pressao: anaAcerta(q) ? oppPerfil.pressao : ["baixa", "media", "alta"][Math.floor(Math.random() * 3)],
    mentalidade: anaAcerta(q) ? oppPerfil.mentalidade : ["defensivo", "equilibrado", "ofensivo"][Math.floor(Math.random() * 3)],
    sistema: oppPerfil.sistema,
    grTaxa: anaRuido(oppPerfil.grTaxa, q, 0.25, 0, 1),
    dependencia: anaRuido(oppPerfil.dependencia, q, 0.35, 0, 1),
    bpAmeaca: anaRuido(oppPerfil.bpAmeaca, q, 0.4, 0, 1),
  };
  const melhor = ANA_CM_IDS.map(id => ({ id, r: ANA_CM[id].rel(perc) })).sort((a, b) => b.r - a.r)[0];
  return melhor && melhor.r >= ANA_REL_MIN ? [melhor.id] : [];
}
// Chamado no fim de newMatchState: prepara ctx.analise para os dois lados.
function anaAplicar(ctx){
  ctx.analise = null; ctx.grPuxado = { home: 0, away: 0 };
  if(ctx.isFriendly) return;
  const home = state.teams[ctx.homeId], away = state.teams[ctx.awayId];
  if(!home || !away) return;
  const perfis = { home: anaPerfilReal(home), away: anaPerfilReal(away) };
  const lados = {};
  ["home", "away"].forEach(side => {
    const team = side === "home" ? home : away, opp = side === "home" ? away : home;
    const oppPerfil = perfis[side === "home" ? "away" : "home"];
    let ids = [], origem = "ia";
    if(isUserControlledTeam(team)){
      const esc = anaEscolhasDoJogo(opp.id);
      ids = esc.ids; origem = "utilizador";
      ctx.anaKey = esc.key; ctx.anaUserSide = side;
    } else ids = anaIaEscolhe(team, oppPerfil);
    const ef = anaEfeitos(ids, oppPerfil);
    ef.ids = ids; ef.origem = origem;
    lados[side] = ef;
  });
  ctx.analise = lados; ctx.anaPerfis = perfis;
}
function anaMultRemate(ctx, atk, def){
  if(!ctx.analise) return 1;
  const a = ctx.analise[atk], d = ctx.analise[def];
  let m = a.conv * d.convSof;
  const gr = ctx.semGuardaRedes;
  if(gr && gr[atk]) m *= d.grDef;       // o atacante jogou sem guarda-redes: a defesa treinou o 5 contra 4
  if(gr && gr[def]) m *= a.grAtk;       // baliza vazia do adversário: o ataque treinou-o
  return m;
}
function anaMultBolaParada(ctx, atk, def){
  if(!ctx.analise) return 1;
  return ctx.analise[def].sp;
}
function anaRegistarGr(ctx, side){ if(ctx.grPuxado) ctx.grPuxado[side] = (ctx.grPuxado[side] || 0) + 1; }

// Depois do jogo: verifica contramedidas e relatório e avisa o utilizador.
function anaAposJogo(ctx){
  if(!ctx.analise || !ctx.anaUserSide) return;
  const side = ctx.anaUserSide, oppSide = side === "home" ? "away" : "home";
  const team = state.teams[side === "home" ? ctx.homeId : ctx.awayId], opp = state.teams[oppSide === "home" ? ctx.homeId : ctx.awayId];
  if(!team || !opp) return;
  const A = anaEnsure(), ef = ctx.analise[side], real = ctx.anaPerfis[oppSide];
  const rel = A.relatorios[ctx.anaKey] || null;
  if(!ef.ids.length && !rel) return;
  const partes = [];
  if(ef.detalhe.length){
    ef.detalhe.forEach(d => {
      const cm = ANA_CM[d.id];
      const veredicto = d.rel >= 0.6 ? "acertou no alvo" : d.rel >= 0.2 ? "teve efeito parcial" : "falhou o alvo";
      partes.push(`${cm.label}: ${veredicto}`);
    });
  }
  const verif = [];
  if(rel){
    const p = rel.padroes;
    verif.push(`pressão ${p.pressao === real.pressao ? "certa" : "errada (o adversário jogou com pressão " + (ANA_LABEL_PRESSAO[real.pressao] || real.pressao) + ")"}`);
    verif.push(`mentalidade ${p.mentalidade === real.mentalidade ? "certa" : "errada (jogou de forma " + (ANA_LABEL_MENTALIDADE[real.mentalidade] || real.mentalidade) + ")"}`);
  }
  A.historico.unshift({
    data: anaHoje(), oppId: opp.id, escolhas: ef.detalhe.map(d => ({ id: d.id, rel: d.rel })), fiabilidade: rel ? rel.q : null,
    pressaoCerta: rel ? rel.padroes.pressao === real.pressao : null, mentalidadeCerta: rel ? rel.padroes.mentalidade === real.mentalidade : null,
    resultado: `${ctx.score[side]}-${ctx.score[oppSide]}`,
  });
  if(A.historico.length > 30) A.historico.length = 30;
  const html = repDoc({
    teamId: team.id, org: "Departamento de análise", titulo: "Verificação da análise",
    sub: `Depois do jogo com ${teamLinkHtml(opp.id)} · ${ctx.score[side]}-${ctx.score[oppSide]}`,
    vsId: opp.id, vsTexto: "adversário",
    secoes: [
      { icone:"🛡️", titulo:"Contramedidas", cheia:true, linhas: ef.detalhe.length ? ef.detalhe.map(d => { const cm = ANA_CM[d.id]; return [cm.label, d.rel >= 0.6 ? "acertou no alvo" : d.rel >= 0.2 ? "teve efeito parcial" : "falhou o alvo"]; }) : [] },
      { icone:"🔍", titulo:"O relatório acertou?", cheia:true, linhas: rel ? [
        ["Pressão", rel.padroes.pressao === real.pressao ? "certa" : `errada (o adversário jogou com pressão ${(ANA_LABEL_PRESSAO[real.pressao] || real.pressao).toLowerCase()})`],
        ["Mentalidade", rel.padroes.mentalidade === real.mentalidade ? "certa" : `errada (jogou de forma ${(ANA_LABEL_MENTALIDADE[real.mentalidade] || real.mentalidade).toLowerCase()})`],
      ] : [] },
    ],
    rodape: "Verificação da análise do adversário",
  });
  pushNews(state.currentDate, html, "tatica", `Verificação da análise: ${opp.name}`);
  delete A.escolhas[ctx.anaKey];
}

// ---------------------------------------------------------------- relatório do adjunto
function anaLinhaAdjunto(fixture){
  if(!fixture) return "";
  const team = myTeam(); if(!team) return "";
  const oppId = fixture.home === state.userTeamId ? fixture.away : fixture.home;
  const A = anaEnsure(), nx = anaProximoJogo();
  const k = nx && nx.oppId === oppId ? nx.key : anaChaveDoJogo(oppId, anaHoje());
  const rel = A.relatorios[k], esc = A.escolhas[k] || [];
  if(rel) return `Análise do departamento: pronta (fiabilidade ${anaFiabilidade(rel.q).toLowerCase()})${esc.length ? ` · contramedidas: ${esc.map(id => ANA_CM[id].label).join(", ")}` : ""}.<br>`;
  if(A.pedidos.some(p => p.key === k)) return "Análise do departamento: em curso.<br>";
  return esc.length ? `Contramedidas escolhidas: ${esc.map(id => ANA_CM[id].label).join(", ")} (sem relatório do departamento).<br>` : "Análise detalhada: podes pedi-la em Táticas (custa dinheiro e demora alguns dias).<br>";
}

// ---------------------------------------------------------------- painel (Táticas)
// 2026-10-12 (pedido do utilizador): as contramedidas são para UM jogo concreto, por isso saem do fundo do
// painel (misturadas com o departamento) e passam a um bloco próprio, junto da mentalidade e da pressão,
// com o jogo identificado no título. O departamento e o histórico ficam no fundo (anaPanelHtml).
function anaJogoHtml(team){
  if(!team || !isUserControlledTeam(team)) return "";
  const A = anaEnsure(), cfg = ANA_NIVEIS[anaNivel(team)];
  const nx = anaProximoJogo();
  const opp = nx ? state.teams[nx.oppId] : null;
  const rel = nx ? A.relatorios[nx.key] : null;
  const pedido = nx ? A.pedidos.find(p => p.key === nx.key) : null;
  const esc = nx ? (A.escolhas[nx.key] || []) : [];
  if(!nx) return `<div class="eyebrow" style="margin:20px 0 8px;">Para o próximo jogo</div><p class="helptext">Sem jogos agendados.</p>`;
  const loc = { C: "em casa", F: "fora", N: "campo neutro" }[nx.local] || "";
  const quando = nx.dias <= 0 ? "hoje" : "daqui a " + nx.dias + " dia" + (nx.dias === 1 ? "" : "s");
  let estado = "";
  if(rel) estado += `<details open><summary class="helptext" style="cursor:pointer;">Relatório do adversário pronto (fiabilidade ${anaFiabilidade(rel.q).toLowerCase()})</summary><div class="helptext" style="margin:6px 0;">${anaRelatorioHtml(rel)}</div></details>`;
  else if(pedido) estado += `<p class="helptext">Análise em curso: pronta em ${fmtDateShort(new Date(pedido.pronta))}${pedido.apressada ? " (apressada, com menor fiabilidade)" : ""}.</p>`;
  else {
    const apressada = nx.dias < cfg.dias;
    estado += nx.dias < 1 ? `<p class="helptext">O jogo é hoje: já não há tempo para pedir uma análise.</p>` :
      `<button class="btn btn-ghost ana-pedir">Pedir análise do adversário (${fmtMoney(anaCustoRelatorio(team))}, ${Math.min(cfg.dias, nx.dias)} dia${Math.min(cfg.dias, nx.dias) === 1 ? "" : "s"})</button>${apressada ? ` <span class="helptext">Com ${nx.dias} dia${nx.dias === 1 ? "" : "s"} até ao jogo a análise sai apressada.</span>` : ""}`;
  }
  const cms = ANA_CM_IDS.map(id => {
    const cm = ANA_CM[id], marcado = esc.includes(id);
    const sug = rel && rel.sugeridas.includes(id);
    return `<label style="display:flex;gap:8px;align-items:flex-start;margin:4px 0;"><input type="checkbox" class="ana-cm" data-id="${id}" ${marcado ? "checked" : ""}>
      <span><b>${cm.label}</b>${sug ? ' <span class="helptext">(sugerida pelo relatório)</span>' : ""}<br><span class="helptext">${cm.texto}</span></span></label>`;
  }).join("");
  return `<div class="ana-jogo" style="border:1.5px solid var(--laranja);border-radius:8px;padding:10px 12px;margin:20px 0 8px;">
    <div class="eyebrow" style="margin:0 0 4px;">Para este jogo · contramedidas</div>
    <p class="helptext" style="margin-bottom:6px;"><b>${opp ? escapeHtml(opp.name) : "?"}</b> (${loc}, ${fmtDateShort(new Date(nx.data))}, ${escapeHtml(nx.competicao)}) · ${quando}. <b>Só valem para este jogo</b> — depois dele há que escolher de novo.</p>
    ${estado}
    <div class="eyebrow" style="margin:12px 0 4px;">Contramedidas contra o ${opp ? escapeHtml(opp.name) : "adversário"} (até ${ANA_MAX_ESCOLHAS})</div>
    <p class="helptext" style="margin-bottom:4px;">Cada contramedida dá um pequeno bónus se acertar no padrão real do adversário e um pequeno prejuízo se falhar. Sem relatório, é um palpite.</p>${cms}
  </div>`;
}
// Departamento de análise e histórico (permanentes, não dependem de um jogo).
function anaPanelHtml(team){
  if(!team || !isUserControlledTeam(team)) return "";
  const A = anaEnsure(), nivel = anaNivel(team), cfg = ANA_NIVEIS[nivel];
  const niveis = Object.keys(ANA_NIVEIS).map(n => {
    const c = ANA_NIVEIS[n], atual = Number(n) === nivel;
    const custo = Number(n) > nivel ? ` (instalação ${fmtMoney(anaCustoSubida(team, Number(n)))})` : "";
    return `<button class="btn btn-ghost ana-nivel" data-nivel="${n}" ${atual ? "disabled" : ""}>${c.label}${custo}</button>`;
  }).join(" ");
  const hist = A.historico.slice(0, 5).map(h => {
    const o = state.teams[h.oppId];
    const acertos = h.escolhas.filter(e => e.rel >= 0.6).length;
    return `<tr><td>${fmtDateShort(new Date(h.data))}</td><td>${o ? escapeHtml(o.name) : "?"}</td><td>${h.resultado}</td><td>${h.escolhas.length ? acertos + "/" + h.escolhas.length : "—"}</td><td>${h.fiabilidade != null ? anaFiabilidade(h.fiabilidade) : "—"}</td></tr>`;
  }).join("");
  return `<div class="eyebrow" style="margin:20px 0 8px;">Departamento de análise</div>
    <p class="helptext" style="margin-bottom:6px;">Departamento: <b>${cfg.label}</b> · encargo mensal ${fmtMoney(anaCustoMensal(team))}. Melhor departamento: relatórios mais fiáveis e mais rápidos (${cfg.dias} dia${cfg.dias === 1 ? "" : "s"}). Os relatórios e as contramedidas de cada jogo estão acima, junto da mentalidade e da pressão.</p>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">${niveis}</div>
    ${hist ? `<details><summary class="helptext" style="cursor:pointer;">Últimas análises</summary><table class="data-table" style="width:100%;font-size:12px;"><thead><tr><th>Data</th><th>Adversário</th><th>Res.</th><th>Contram. certeiras</th><th>Fiabilidade</th></tr></thead><tbody>${hist}</tbody></table></details>` : ""}`;
}
document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const redraw = () => { if(typeof renderTaticasView === "function") renderTaticasView(); };
  if(t.closest(".ana-pedir")){
    const r = anaPedir();
    showTransientNotice(r.ok ? `Análise pedida (${fmtMoney(r.custo)}).` : r.reason); redraw(); return;
  }
  const nv = t.closest(".ana-nivel");
  if(nv){
    const r = anaMudarNivel(Number(nv.getAttribute("data-nivel")));
    showTransientNotice(r.ok ? "Departamento atualizado." : r.reason); redraw(); return;
  }
  const cm = t.closest(".ana-cm");
  if(cm){
    const box = document.getElementById("taticasContent"); if(!box) return;
    const marcados = Array.from(box.querySelectorAll(".ana-cm")).filter(x => x.checked).map(x => x.getAttribute("data-id"));
    if(marcados.length > ANA_MAX_ESCOLHAS){ cm.checked = false; showTransientNotice(`No máximo ${ANA_MAX_ESCOLHAS} contramedidas.`); return; }
    anaEscolher(marcados);
  }
});
